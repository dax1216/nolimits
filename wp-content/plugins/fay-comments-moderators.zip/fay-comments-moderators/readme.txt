=== WP Comments Moderators ===

Contributors: Fayçal Tirich
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=HDB7NGZL7BDXG&lc=US&item_name=%2eFay%20Labs&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted
Tags: comment, moderate, moderation
Requires at least: 3.0
Tested up to: 3.7.1
Stable tag: 4.0.2

WP Comments Moderators plugin allows any user (whatever their Role) to moderate any blog comment.

== Description ==

WP Comments Moderators plugin allows any user (whatever their Role) to moderate any blog comment.

Wordpress only allows users with Administrator|Editor role to moderate comments. Those two roles give much more than our need, if you are scared about your blog and dreamed about a lightweight solution, this plugin can be helpful for you.

== Installation ==

1. Upload `fay-comments-moderators` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'Com'Moderators' menu
4. Allow your users

== Frequently Asked Questions ==

=  =

== Changelog ==
= 4.0.2 =
* Introducing CodeCanyon profile

= 4.0.1 =
* Asking for donation, please help me buy a smartphone

= 4.0 =
* Rewriting the whole plugin to be compatible with WP 3
* Adding privileges to moderate also pages comments and not only posts
* Many thanks to Marcelo R. from http://hypescience.com/

= 3.1 =
* Fix minor bug

= 3.0 =
* More restrictions for Subscriber role
* Also send moderation notification to new moderators 

= 2.1 =
* Fix problems with users from Subscriber role

= 2.0 =
* Fix the compatibility with Wordpress 2.7.x

= 1.0 =
* First release with no bug detected



== Screenshots ==

1. This is how the settings page will look