fv-thoughtful-comments
======================

FV Thoughtful Comments adds advanced front end comment moderation and cool thread and user banning mechanisms.
=======
Manage incomming comments more effectively by using frontend comment moderation system provided by this plugin.
